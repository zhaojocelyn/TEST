package Rebalancing

case class RebalanceTrade(ticker: String, transType: String, qty: Double) {
  override def toString: String = s"$ticker,$transType,$qty"
}