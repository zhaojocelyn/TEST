package Rebalancing

import MarketData.MarketSnapshot
import Model.{Portfolio, TargetModel}

case class Rebalancer(targetModel: TargetModel) {

  def rebalance(currentPortfolio: Portfolio, market: MarketSnapshot): List[RebalanceTrade] = {
    val nav = currentPortfolio.getNav(market)
    val targetRatio = targetModel.getRatio(market).toMap //Again, assumes has ratio for all tickets and returns 0 otherwise
    val targetTrades = currentPortfolio.positions.map(p => {
        val price = market.getPrice(p.ticker)
        convertToTrade(p.ticker, (nav * targetRatio.getOrElse(p.ticker, 0.0) - p.qty * price)/price)
      })
    targetTrades
  }

  private def convertToTrade(ticker: String, deltaQty: Double): RebalanceTrade = {
    RebalanceTrade(ticker, if (deltaQty >= 0.0) "Buy" else "Sell", deltaQty.abs)
  }
}
