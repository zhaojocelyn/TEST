import MarketData.{MarketSnapshot, PriceData}
import Model.{Portfolio, Position, TargetModel}
import Rebalancing.Rebalancer
import org.apache.log4j.{Level, Logger}
import org.apache.spark.{SparkConf, SparkContext}

object RebalancerApp {

  def main(args: Array[String]) {
    Logger.getLogger("org").setLevel(Level.OFF)
    System.setProperty("hadoop.home.dir", "c:\\winutil\\")

    val conf = new SparkConf().setAppName("Spark Rebalancer").setMaster("local")
    val sc = new SparkContext(conf)

    val marketDataFile = "marketdata.csv"
    val portfolioFileNames = "pofoliofiles.txt"
    val modelPortfolioFile = "modelPortfolio.csv"

    val marketSnapshot = loadMarketData(sc, marketDataFile)
    println(s"\nLoaded market data from $marketDataFile:\n $marketSnapshot")

    val targetModel = loadTargetModel(sc, modelPortfolioFile)
    println(s"\nLoaded target model from $modelPortfolioFile:\n $targetModel")

    val allPortfolios = loadAllportfolios(sc, portfolioFileNames)
    println(s"\nLoaded all portfolios defined in $portfolioFileNames:\n ${allPortfolios.mkString("\n")}")

    val rebalancer = Rebalancer(targetModel)
    println(s"\nStarting to rebalance")
    val start = System.currentTimeMillis()
    val allTrades = sc.parallelize(allPortfolios).map(port => {
      val trades = rebalancer.rebalance(port, marketSnapshot)
      trades.map(t => s"${port.name},$t").mkString("\n")
    }).coalesce(1).saveAsTextFile("trades-output")
    sc.stop()
  }

  private def loadMarketData(sc: SparkContext, marketDataFile: String): MarketSnapshot = {
    val priceData = sc.textFile(marketDataFile).map(l => PriceData.fromArray(l.split(","))).collect()
    MarketSnapshot(priceData.toList)
  }

  private def loadTargetModel(sc: SparkContext, modelPortfolioFile: String): TargetModel = {
    val modelPortfolioPositions = sc.textFile(modelPortfolioFile).map(l => Position.fromArray(l.split(","))).collect()
    val targetPortfolio = Portfolio("Model Portfolio", modelPortfolioPositions.toList)
    TargetModel(targetPortfolio)
  }

  private def loadAllportfolios(sc: SparkContext, modelPortfolioFile: String): List[Portfolio] = {
    val portfolioNames = sc.textFile(modelPortfolioFile).collect()
    portfolioNames.map(port => {
      val positions = sc.textFile(port, 2).map(l => Position.fromArray(l.split(","))).collect()
      Portfolio(port, positions.toList)
    }).toList
    //TODO: below doesn't work
    /*
    sc.parallelize(portfolioNames).map(portFile => {
      val positions = sc.textFile(portFile).map(l => Position.fromArray(l.split(","))).collect()
      Portfolio(positions.toList)
    }).collect().toList
    */
  }
}
