package Model

import MarketData.MarketSnapshot

case class TargetModel(modelPort: Portfolio) {
  /**
    * ticket -> ratio, satisfying sum(ratio) = 1
    */
  def getRatio(market: MarketSnapshot): List[(String, Double)] = {
    //Assumes market has market data for all tickers in model portfolio
    val priceMap = market.priceData.map(p => (p.ticker, p.price)).toMap
    val weights = modelPort.positions.map(p => (p.ticker, p.qty * priceMap.getOrElse(p.ticker, 0.0)))
    val sumWeights = weights.map(_._2).sum
    weights.map(p => (p._1, p._2/sumWeights))
  }
}