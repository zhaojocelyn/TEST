package Model

import MarketData.MarketSnapshot

case class Portfolio(name: String, positions: List[Position]) {
  def getNav(marketData: MarketSnapshot): Double = positions.map(p => marketData.getPrice(p.ticker) * p.qty).sum
}
