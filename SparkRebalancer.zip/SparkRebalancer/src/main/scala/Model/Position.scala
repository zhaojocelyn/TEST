package Model

case class Position(ticker: String, qty: Double)

object Position {
  /**
    * Assumes input is good
    */
  def fromArray(arr: Array[String]): Position = {
    Position(arr(0), arr(1).toDouble)
  }
}