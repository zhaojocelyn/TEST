package MarketData

case class PriceData(ticker: String, price: Double)

object PriceData {
  /**
    * Assumes data is clean
    */
  def fromArray(arr: Array[String]): PriceData = {
    PriceData(arr(0), arr(1).toDouble)
  }
}