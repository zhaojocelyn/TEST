package MarketData

case class MarketSnapshot(priceData: List[PriceData]) {
  lazy val priceMap = priceData.map(p => (p.ticker, p.price)).toMap

  /**
    * for now simply returns 0 if not found
    */
  def getPrice(ticker: String): Double = {
    priceMap.getOrElse(ticker, 0.0)
  }
}
