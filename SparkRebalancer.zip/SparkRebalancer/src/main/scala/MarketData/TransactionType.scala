package MarketData

trait TransactionType{
  val transType: String
}

object Sell extends TransactionType {
  override val transType: String = "SELL"
}

object Buy extends TransactionType {
  override val transType: String = "Buy"
}